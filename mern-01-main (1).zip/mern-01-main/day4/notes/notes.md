## Express

- installation of utilities

```bash
# for windows
> npm install -g yarn nodemon

# for linux and mac
> sudo npm install -g yarn nodemon
```

- installation of express

```bash
> npm install express
> yarn add express
```

## mongoose

- install mongoose

  ```bash
  > npm install mongoose
  > yarn add mongoose
  ```

- connect to the mongodb using mongoose

  - add the following code in app.js

  ```javascript
  // import the mongoose
  const mongoose = require('mongoose')

  // connect the mongo db
  // if database does not exist, mongoose creates an empty database
  mongoose.connect('mongodb://localhost:27017/tweeter')
  ```

- create a model for a collection

  - a model represents a collection
  - a model instance (object) represents a document inside the collection

    ```javascript
    // import mongoose
    const mongoose = require('mongoose')

    // create a model schema
    const UserSchema = new mongoose.Schema({
      name: String,
      email: String,
      password: String,
    })

    // create a model (collection) named User
    // Note:
    // - model name: User => collection name: users
    module.exports = mongoose.model('User', UserSchema)
    ```

- create an instance of required model to create a document in respective collection

  ```javascript
  // create an instance of user model
  const user = new User()
  user.name = 'user1'
  user.email = 'user1@test.com'
  user.password = 'test'

  // save the user instance to create a document inside the User collection
  user.save((error, result) => {
    console.log(result)
    response.send('user signed up')
  })
  ```

## Crypto-JS

- installation

  ```bash
  > npm install crypto-js
  > yarn add crypto-js
  ```

- usage

  ```javascript
  // import crypto-js for encrypting password
  const CryptoJs = require('crypto-js')

  // plain text
  const password = 'test'

  // encrypted password
  const encrypted = CryptoJs.SHA256(password)
  ```

## JWT

- installation

  ```bash
  > npm install jsonwebtoken
  > yarn add jsonwebtoken
  ```

- create a token

  ```javascript
  const jwt = require('jsonwebtoken')
  const token = jwt.sign({ id: '61da7a4b9ef3e1652b797cbe' }, 'secret')
  ```

- verify the token

  ```javascript
  const jwt = require('jsonwebtoken')

  const token = jwt.sign({ _id_: '61da7a4b9ef3e1652b797cbe' }, 'secret')
  const decoded = jwt.verify(token, 'secret')

  // { id: '61da7a4b9ef3e1652b797cbe' }
  console.log(decoded)
  ```
