// import express
const express = require('express')

// create an express application
const app = express()

// routes
app.get('/', (request, response) => {
  response.send('<h1>Welcome to the Application Backend</h1>')
})

// user
app.post('/user/signup', (request, response) => {
  response.send('user signed up')
})

app.post('/user/signin', (request, response) => {
  response.send('user signed in')
})

app.put('/user/profile', (request, response) => {
  response.send('user profile updated')
})

// tweet
app.post('/tweet/', (request, response) => {
  response.send('tweet created')
})

app.put('/tweet/', (request, response) => {
  response.send('tweet updated')
})

app.get('/tweet/', (request, response) => {
  response.send('list of tweets')
})

// start the express application to listen on port 4000
app.listen(4000, '0.0.0.0', () => {
  console.log('server has started successfully on port 4000')
})
