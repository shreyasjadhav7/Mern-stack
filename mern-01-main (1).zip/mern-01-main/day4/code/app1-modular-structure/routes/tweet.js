// import express
const express = require('express')

// get the router object
// it is responsible for adding the routes to the main application
const router = express.Router()

router.post('/', (request, response) => {
  response.send('tweet created')
})

router.put('/', (request, response) => {
  response.send('tweet updated')
})

router.get('/', (request, response) => {
  response.send('list of tweets')
})

// export router so that we can add these routes
// into the main application in server.js
module.exports = router
