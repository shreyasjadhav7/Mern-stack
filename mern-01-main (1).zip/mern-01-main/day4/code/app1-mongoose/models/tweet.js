// import mongoose
const mongoose = require('mongoose')

// create a model schema
const TweetSchema = new mongoose.Schema({
  title: String,
  message: String,
  date: { type: Date, default: new Date() },

  // this tweet is owned by a user
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
})

// create a model (collection) named Tweet
// Note:
// - model name: Tweet => collection name: tweets
module.exports = mongoose.model('Tweet', TweetSchema)

// db.tweets.aggregate([
//   {
//     $lookup: {
//       from: 'users',
//       localField: 'user',
//       foreignField: '_id',
//       as: 'User'
//     }
//   }
// ])
