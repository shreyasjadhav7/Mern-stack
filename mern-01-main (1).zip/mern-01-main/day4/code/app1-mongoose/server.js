// import express
const express = require('express')

// create an express application
const app = express()

// import the mongoose
const mongoose = require('mongoose')

// connect the mongo db
// if database does not exist, mongoose creates an empty database
mongoose.connect('mongodb://localhost:27017/tweeter')

// with this setting, the server will parse
// the request body with json parser and
// converting it to a json object
app.use(express.json())

// routes
app.get('/', (request, response) => {
  response.send('<h1>Welcome to the Application Backend</h1>')
})

// import router modules
const routerUser = require('./routes/user')
const routerTweet = require('./routes/tweet')

// add the routes
app.use('/user', routerUser)
app.use('/tweet', routerTweet)

// start the express application to listen on port 4000
app.listen(4000, '0.0.0.0', () => {
  console.log('server has started successfully on port 4000')
})
