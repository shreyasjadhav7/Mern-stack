// import express
const express = require('express')

// import user model
const User = require('../models/user')

// get the router object
// it is responsible for adding the routes to the main application
const router = express.Router()

router.post('/signup', (request, response) => {
  const { name, email, password } = request.body

  // create an instance of user model
  const user = new User()
  user.name = name
  user.email = email
  user.password = password

  // save the user instance to create a document inside the User collection
  user.save((error, result) => {
    console.log(result)
    response.send('user signed up')
  })
})

router.post('/signin', (request, response) => {
  response.send('user signed in')
})

router.put('/profile', (request, response) => {
  response.send('user profile updated')
})

// export router so that we can add these routes
// into the main application in server.js
module.exports = router
