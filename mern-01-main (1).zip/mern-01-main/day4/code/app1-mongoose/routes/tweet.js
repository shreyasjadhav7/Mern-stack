// import express
const express = require('express')

// import the tweet model
const Tweet = require('../models/tweet')

// get the router object
// it is responsible for adding the routes to the main application
const router = express.Router()

router.post('/', (request, response) => {
  const { title, message, user } = request.body

  // create a new tweet document
  const tweet = new Tweet()
  tweet.title = title
  tweet.message = message
  tweet.user = user

  // save the tweet document
  tweet.save((error, result) => {
    console.log(result)
    response.send('tweet created')
  })
})

router.put('/', (request, response) => {
  response.send('tweet updated')
})

router.get('/', (request, response) => {
  Tweet.find()

    // do the lookup behind the scene
    .populate('user', 'name email')
    .exec((error, tweets) => {
      response.send(tweets)
    })
})

// export router so that we can add these routes
// into the main application in server.js
module.exports = router
