// import mongoose
const mongoose = require('mongoose')

// create a model schema
const UserSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  address1: String,
  address2: String,
  city: String,
  state: String,
  country: String,
  postalCode: String,
  birthDate: String,
})

// create a model (collection) named User
// Note:
// - model name: User => collection name: users
module.exports = mongoose.model('User', UserSchema)
