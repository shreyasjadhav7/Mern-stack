// import express
const express = require('express')

// import user model
const User = require('../models/user')

// import crypto-js for encrypting password
const CryptoJs = require('crypto-js')

// import utils for creating result
const utils = require('../utils')

// get the router object
// it is responsible for adding the routes to the main application
const router = express.Router()

router.post('/signup', (request, response) => {
  const { name, email, password } = request.body

  // create an instance of user model
  const user = new User()
  user.name = name
  user.email = email
  user.password = `${CryptoJs.SHA256(password)}`

  // save the user instance to create a document inside the User collection
  user.save((error, result) => {
    response.send(utils.createResult(error, result))
  })
})

router.post('/signin', (request, response) => {
  const { email, password } = request.body

  User.findOne({ email: email, password: `${CryptoJs.SHA256(password)}` }).exec(
    (error, user) => {
      if (error) {
        response.send({ status: 'error', error: error })
      } else if (!user) {
        response.send({ status: 'error', error: 'invalid email or password' })
      } else {
        response.send({ status: 'success', data: 'successfully logged in' })
      }
    }
  )
})

// id here is a variable which holds the value at that position
router.get('/profile/:id', (request, response) => {
  // read the value of id from url
  const { id } = request.params

  // find the user with id
  User.findOne({ _id: id }, { __v: 0, password: 0 }).exec((error, user) => {
    response.send(utils.createResult(error, user))
  })
})

router.put('/profile/:id', (request, response) => {
  // get the id of the user whose profile will get updated
  const { id } = request.params

  // get the profile details
  const { address1, address2, city, state, country, postalCode, birthDate } =
    request.body

  // find the user with id
  User.findOne({ _id: id }, { __v: 0, password: 0 }).exec((error, user) => {
    // update the profile
    user.address1 = address1
    user.address2 = address2
    user.city = city
    user.state = state
    user.country = country
    user.postalCode = postalCode
    user.birthDate = birthDate

    // now save the user profile
    user.save((error, updatedUser) => {
      response.send(utils.createResult(error, updatedUser))
    })
  })
})

// export router so that we can add these routes
// into the main application in server.js
module.exports = router
