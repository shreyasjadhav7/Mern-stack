// import express
const express = require('express')

// import the tweet model
const Tweet = require('../models/tweet')

// import utils for creating result
const utils = require('../utils')

// get the router object
// it is responsible for adding the routes to the main application
const router = express.Router()

router.post('/', (request, response) => {
  const { title, message, user } = request.body

  // create a new tweet document
  const tweet = new Tweet()
  tweet.title = title
  tweet.message = message
  tweet.user = user

  // save the tweet document
  tweet.save((error, result) => {
    response.send(utils.createResult(error, result))
  })
})

router.put('/', (request, response) => {
  response.send('tweet updated')
})

router.get('/', (request, response) => {
  Tweet.find()

    // do the lookup behind the scene
    .populate('user', 'name email')
    .exec((error, tweets) => {
      response.send(utils.createResult(error, tweets))
    })
})

// export router so that we can add these routes
// into the main application in server.js
module.exports = router
