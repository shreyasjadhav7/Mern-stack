// import express
const express = require('express')

// import user model
const User = require('../models/user')

// import crypto-js for encrypting password
const CryptoJs = require('crypto-js')

// import utils for creating result
const utils = require('../utils')

// import jwt for creating a token
const jwt = require('jsonwebtoken')

// import config to read the secret
const config = require('../config')

// get the router object
// it is responsible for adding the routes to the main application
const router = express.Router()

router.post('/signup', (request, response) => {
  const { name, email, password } = request.body

  // create an instance of user model
  const user = new User()
  user.name = name
  user.email = email
  user.password = `${CryptoJs.SHA256(password)}`

  // save the user instance to create a document inside the User collection
  user.save((error, result) => {
    response.send(utils.createResult(error, result))
  })
})

router.post('/signin', (request, response) => {
  const { email, password } = request.body

  User.findOne({ email: email, password: `${CryptoJs.SHA256(password)}` }).exec(
    (error, user) => {
      if (error) {
        response.send({ status: 'error', error: error })
      } else if (!user) {
        response.send({ status: 'error', error: 'invalid email or password' })
      } else {
        // create payload which will be sent to the client
        // and client will send it back every time while calling API
        const payload = {
          id: user._id,
        }

        // create jwt token
        const token = jwt.sign(payload, config.secret)

        // send the token to the user
        response.send({
          status: 'success',
          data: {
            email: user.email,
            name: user.name,
            token: token,
          },
        })
      }
    }
  )
})

// id here is a variable which holds the value at that position
router.get('/profile', (request, response) => {
  // find the user with id
  // request has a new parameter named userId (added by the middleware which
  // is written in server.js)
  User.findOne({ _id: request.userId }, { __v: 0, password: 0 }).exec(
    (error, user) => {
      response.send(utils.createResult(error, user))
    }
  )
})

router.put('/profile/', (request, response) => {
  // get the profile details
  const { address1, address2, city, state, country, postalCode, birthDate } =
    request.body

  // find the user with id
  // request has a new parameter named userId (added by the middleware which
  // is written in server.js)
  User.findOne({ _id: request.userId }, { __v: 0, password: 0 }).exec(
    (error, user) => {
      // update the profile
      user.address1 = address1
      user.address2 = address2
      user.city = city
      user.state = state
      user.country = country
      user.postalCode = postalCode
      user.birthDate = birthDate

      // now save the user profile
      user.save((error, updatedUser) => {
        response.send(utils.createResult(error, updatedUser))
      })
    }
  )
})

// export router so that we can add these routes
// into the main application in server.js
module.exports = router
