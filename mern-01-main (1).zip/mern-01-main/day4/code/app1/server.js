// import express
const express = require('express')

// import config to read the secret
const config = require('./config')

// import jwt for creating a token
const jwt = require('jsonwebtoken')

// import cors for letting client to call the APIs
const cors = require('cors')

// import morgan to log all the incoming requests
const morgan = require('morgan')

// import fs to create a file to store logs
const fs = require('fs')

// import path to create the file on the current directory
const path = require('path')

// create an express application
const app = express()

// use the cors rules
app.use(cors('*'))

// use the morgan and add the logging requests feature
// app.use(morgan('combined'))

// create a write stream (in append mode)
const accessLogStream = fs.createWriteStream(
  path.join(__dirname, 'access.log'),
  { flags: 'a' }
)

// setup the logger
app.use(morgan('combined', { stream: accessLogStream }))

// import the mongoose
const mongoose = require('mongoose')

// connect the mongo db
// if database does not exist, mongoose creates an empty database
mongoose.connect('mongodb://localhost:27017/tweeter')

// with this setting, the server will parse
// the request body with json parser and
// converting it to a json object
app.use(express.json())

// routes
app.get('/', (request, response) => {
  response.send('<h1>Welcome to the Application Backend</h1>')
})

// add a middleware
// - function which gets called every time (irrespective of the api being called)
// - parameters
//   - request: user's input
//   - response: output the application will send
//   - next: reference to the next function/route to be called
app.use((request, response, next) => {
  console.log(`middleware is getting called`)

  if (request.url == '/user/signup' || request.url == '/user/signin') {
    // token verification is not needed
    // go the next function
    next()
  } else {
    // read the token from headers
    const token = request.headers['token']

    if (token) {
      try {
        // decode the token and get the user id
        const data = jwt.verify(token, config.secret)

        // get the id from the data and pass it to the next handler
        // by adding a new parameter in the request object
        request.userId = data.id

        // call the next function/route/handler
        next()
      } catch (ex) {
        // unauthorized
        response.status(401)
        response.send('invalid token')
      }
    } else {
      // unauthorized
      response.status(401)
      response.send('missing token')
    }
  }
})

// import router modules
const routerUser = require('./routes/user')
const routerTweet = require('./routes/tweet')

// add the routes
app.use('/user', routerUser)
app.use('/tweet', routerTweet)

// start the express application to listen on port 4000
app.listen(4000, '0.0.0.0', () => {
  console.log('server has started successfully on port 4000')
})
