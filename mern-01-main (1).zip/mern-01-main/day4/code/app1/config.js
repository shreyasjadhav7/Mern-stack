const config = {
  secret: 'b2VQXKIrB7urfisPxHuLss6Z2oTMR2MC',
}

module.exports = config
