import counter from './reducers/countReducer'
import { composeWithDevTools } from 'redux-devtools-extension'
import { combineReducers, createStore } from 'redux'

// create a global store
const store = createStore(combineReducers({ counter }), composeWithDevTools())

export default store
