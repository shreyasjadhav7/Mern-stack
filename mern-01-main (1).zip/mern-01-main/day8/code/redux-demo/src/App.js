import logo from './logo.svg'
import './App.css'
import First from './components/First'
import Second from './components/Second'
import Third from './components/Third'

function App() {
  return (
    <div className="App">
      <First />
      <hr />
      <Second />
      <hr />
      <Third />
    </div>
  )
}

export default App
