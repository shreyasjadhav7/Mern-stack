import { useSelector } from 'react-redux'

const Third = () => {
  const counter = useSelector((state) => state.counter)

  return (
    <div>
      <h1>Third Component</h1>

      <p>counter {counter}</p>
    </div>
  )
}

export default Third
