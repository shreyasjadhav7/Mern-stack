const express = require('express')
const cors = require('cors')
const morgan = require('morgan')
const mongoose = require('mongoose')
const config = require('./config')
const jwt = require('jsonwebtoken')
const utils = require('./utils')
const moment = require('moment')
const User = require('./models/user')

// connect to the database
mongoose.connect(`mongodb://${config.db}`)

const app = express()
app.use(cors('*'))
app.use(morgan('combined'))
app.use(express.json())
app.use(express.urlencoded())
app.use(express.static('./images'))

// check for the token in the api
app.use(async (request, response, next) => {
  if (
    request.url == '/user/signin' ||
    request.url == '/user/signup' ||
    request.url.startsWith('/user/profile-image') ||
    request.url == '/user/forgot-password'
  ) {
    // skip the request
    next()
  } else {
    const token = request.headers['token']
    if (!token) {
      response.status(401)
      response.send(utils.createError('missing token'))
    } else {
      try {
        // take the basic info about the user who is calling the api
        const data = jwt.verify(token, config.secrete)

        // handle token expiration logic
        const tokenDateTime = moment.unix(data.iat)
        const currentDateTime = moment()

        // get the difference
        const differenceInMinutes = currentDateTime.diff(
          tokenDateTime,
          'minutes'
        )

        console.log(`difference in minutes = ${differenceInMinutes}`)

        // let the token be active only for 15 minutes
        if (differenceInMinutes > 10000) {
          response.status(401)
          response.send(utils.createError('expired token'))
          return
        }

        //TODO: check if user is deleted
        const user = await User.findOne({ _id: data.id })

        if (user.isDeleted) {
          response.status(401)
          response.send(utils.createError('your account is deleted'))
          return
        }

        request.name = data.name
        request.email = data.email
        request.userId = data.id
        request.handle = data.handle
        request.user = user

        next()
      } catch (ex) {
        response.status(401)
        response.send(utils.createError('invalid token'))
      }
    }
  }
})

// add routes
const routerUser = require('./routes/user')
const routerTweet = require('./routes/tweet')

app.use('/user', routerUser)
app.use('/tweet', routerTweet)

app.listen(4000, '0.0.0.0', () => {
  console.log(`server started on port 4000`)
})
