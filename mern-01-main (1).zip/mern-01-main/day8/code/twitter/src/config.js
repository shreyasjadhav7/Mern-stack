const config = {
  server: 'http://34.203.243.93:4000',
}

export default config
