import { createUrl } from '../services/utils'

const UserPreview = (props) => {
  const { _id, firstName, lastName, handle, profileImage } = props.user

  const styles = {
    profileImage: {
      width: '50px',
      height: '50px',
      borderRadius: '25px',
      float: 'left',
    },
    userName: {
      fontSize: '20px',
      fontWeight: '800',
    },

    handle: {
      fontSize: '18px',
    },

    btnFollow: {
      position: 'absolute',
      width: '70px',
      height: '30px',
      marginTop: '20px',
      marginRight: '10px',
      right: '0',
      backgroundColor: 'black',
      color: 'white',
      border: 'none',
      fontSize: '14px',
      fontWeight: '700',
      borderRadius: '30px',
    },
  }

  return (
    <div>
      <img
        style={styles.profileImage}
        src={createUrl(`/user/profile-image/${profileImage}`)}
        alt=""
      />
      <div className="row">
        <div className="col">
          <div className="row">
            <div className="col" style={styles.userName}>
              {firstName} {lastName}
            </div>
          </div>
          <div className="row">
            <div style={styles.handle} className="col">
              @{handle}
            </div>
          </div>
        </div>
        <button
          onClick={() => {
            // follow the user
            props.followUser(_id)
          }}
          style={styles.btnFollow}
        >
          Follow
        </button>
      </div>
    </div>
  )
}

export default UserPreview
