import { useState } from 'react'
import { toast } from 'react-toastify'
import colors from '../colors'
import { createTweet } from '../services/tweet'

const CreateTweet = () => {
  const styles = {
    container: {
      marginTop: '10px',

      border: `solid ${colors.gray} 1px`,
      borderRadius: '5px',
      padding: '20px',
    },
    header: {
      fontSize: '20px',
      fontWeight: '800',
    },
    input: {
      marginTop: '20px',
      border: 'none',
      maxHeight: '100px',
      width: '100%',
      outline: 'none',
      resize: 'none',
      display: 'inline-block',
    },
    button: {
      width: '20px',
      height: '20px',
      marginRight: '10px',
    },
    buttonTweetSmall: {
      width: '80px',
      backgroundColor: '#1d9bf0',
      color: 'white',
      border: 'none',
      borderRadius: '15px',
      height: '30px',
      fontSize: '14px',
      boxShadow: 'rgb(0 0 0 / 8%) 0px 8px 28px;',
    },
  }

  const [message, setMessage] = useState('')

  const onCreateTweet = async () => {
    if (message.length === 0) {
      toast.warning('please enter tweet')
    } else {
      const result = await createTweet(message, null)
      if (result['status'] === 'success') {
        toast.success('Successfully created a tweet')
        setMessage('')
      } else {
        toast.error(result['error'])
      }
    }
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>Home</div>
      <textarea
        onChange={(e) => setMessage(e.target.value)}
        type="text"
        style={styles.input}
        placeholder="What's happening ?"
      ></textarea>

      <div className="row">
        <div className="col">
          <img
            style={styles.button}
            src={require('../assets/video.png')}
            alt=""
          />
          <img
            style={styles.button}
            src={require('../assets/image.png')}
            alt=""
          />
        </div>
        <div className="col">
          <div className="float-right" style={{ textAlign: 'right' }}>
            <button onClick={onCreateTweet} style={styles.buttonTweetSmall}>
              Tweet
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CreateTweet
