import { Link } from 'react-router-dom'

const styles = {
  title: {
    color: 'rgb(15, 20, 25)',
    fontSize: '20px',
    marginLeft: '20px',
    textDecoration: 'none',
  },
  container: {
    paddingTop: '20px',
    height: '50px',
  },
}

const MenuItem = (props) => {
  const { title, icon, route } = props.item
  return (
    <div style={styles.container}>
      <Link to={route} style={{ textDecoration: 'none' }}>
        <img src={require('../assets/' + icon)}></img>
        <span style={styles.title}>{title}</span>
      </Link>
    </div>
  )
}

export default MenuItem
