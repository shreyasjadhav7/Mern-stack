import { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { getRecentTweets } from '../services/tweet'
import TweetPreview from './TweetPreview'

const WhatsHappening = () => {
  const [tweets, setTweets] = useState([])

  useEffect(() => {
    ;(async () => {
      const result = await getRecentTweets()
      if (result['status'] === 'success') {
        setTweets(result['data'])
      } else {
        toast.error(result['error'])
      }
    })()
  }, [])

  const styles = {
    header: {
      color: 'rgb(15, 20, 25)',
      fontSize: '20px',
      fontWeight: '800',
      margin: '10px',
    },
    container: {
      marginTop: '10px',
      padding: '10px',
      backgroundColor: '#f7f9f9',
      borderRadius: '20px',
    },
  }
  return (
    <div style={styles.container}>
      <div style={styles.header}>What's Happening</div>

      {tweets.map((item) => {
        return <TweetPreview key={item._id} item={item} />
      })}
    </div>
  )
}

export default WhatsHappening
