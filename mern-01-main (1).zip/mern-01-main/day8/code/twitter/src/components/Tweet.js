import { useEffect, useState } from 'react'
import colors from '../colors'
import { getUserProfile } from '../services/user'
import { createUrl } from '../services/utils'

const Tweet = (props) => {
  const { _id, isDeleted, createdTimestamp, replies, likes, message, user } =
    props.item

  const styles = {
    container: {
      border: `solid ${colors.gray} 1px`,
      padding: '20px',
    },
    image: {
      position: 'absolute',
      width: '50px',
      height: '50px',
      borderRadius: '25px',
    },
    userName: {
      fontSize: '20px',
      fontWeight: '800',
    },
    count: {
      marginTop: '20px',
      display: 'inline-block',
      marginRight: '50px',
    },
  }

  return (
    <div style={styles.container}>
      <img
        style={styles.image}
        src={createUrl(`/user/profile-image/${user.profileImage}`)}
      />
      <div style={{ marginLeft: '50px' }} className="row">
        <div className="row">
          <div className="col" style={styles.userName}>
            {user.firstName} {user.lastName}
          </div>
        </div>
        <div className="row">
          <div className="col" style={{ color: 'black' }}>
            {message}
          </div>
        </div>
        <div className="row">
          <div className="col">
            <div style={styles.count}>
              <img
                style={{ width: '20px', height: '20px' }}
                src={require('../assets/reply.png')}
                alt=""
              />{' '}
              <span style={{ marginLeft: '10px' }}>{replies.length}</span>
            </div>

            <div style={styles.count}>
              <img
                style={{ width: '20px', height: '20px' }}
                src={require('../assets/heart.png')}
                alt=""
              />{' '}
              <span style={{ marginLeft: '10px' }}> {likes.length}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Tweet
