import { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { getAllTweets } from '../services/tweet'
import Tweet from './Tweet'

const Tweets = () => {
  const [tweets, setTweets] = useState([])

  useEffect(() => {
    ;(async () => {
      const result = await getAllTweets()
      if (result['status'] === 'success') {
        setTweets(result['data'])
      } else {
        toast.error(result['error'])
      }
    })()
  }, [])

  return (
    <div>
      {tweets.map((item) => {
        return <Tweet key={item._id} item={item} />
      })}
    </div>
  )
}

export default Tweets
