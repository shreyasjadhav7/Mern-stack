import { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { getTopUsers, toggleFollowUser } from '../services/user'
import UserPreview from './UserPreview'

const WhoToFollow = () => {
  const [users, setUsers] = useState([])

  useEffect(() => {
    loadWhoToFollow()
  }, [])

  const followUser = async (id) => {
    const result = await toggleFollowUser(id)
    if (result['status'] === 'success') {
      toast.success('successfully followed the user')

      // refresh the list
      loadWhoToFollow()
    } else {
      toast.error(result['error'])
    }
  }

  const loadWhoToFollow = async () => {
    const result = await getTopUsers()
    if (result['status'] === 'success') {
      setUsers(result['data'])
    } else {
      toast.error(result['error'])
    }
  }

  const styles = {
    header: {
      color: 'rgb(15, 20, 25)',
      fontSize: '20px',
      fontWeight: '800',
      margin: '10px',
    },
    container: {
      position: 'relative',
      marginTop: '10px',
      padding: '10px',
      backgroundColor: '#f7f9f9',
      borderRadius: '20px',
    },
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>Who to follow</div>

      {users.map((user) => {
        return <UserPreview followUser={followUser} user={user} />
      })}
    </div>
  )
}

export default WhoToFollow
