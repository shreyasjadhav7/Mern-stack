import axios from 'axios'
import { createUrl, getToken } from './utils'

export const login = async (email, password) => {
  const response = await axios.post(createUrl('/user/signin'), {
    email,
    password,
  })

  return response.data
}

export const getTopUsers = async () => {
  const response = await axios.get(createUrl('/user/top'), {
    headers: {
      token: getToken(),
    },
  })

  return response.data
}

export const toggleFollowUser = async (id) => {
  const response = await axios.post(
    createUrl('/user/toggle-follow-status/' + id),
    {},
    {
      headers: {
        token: getToken(),
      },
    }
  )

  return response.data
}

export const getUserProfile = async (fileName) => {
  const response = await axios.get(
    createUrl('/user/profile-image/' + fileName),
    {
      headers: {
        token: getToken(),
      },
    }
  )

  return response.data
}
