import { useNavigate } from 'react-router-dom'
import config from '../config'

export const createUrl = (path) => {
  const url = `${config.server}${path}`
  console.log(`hitting url: ${url}`)
  return url
}

export const getToken = () => {
  if (sessionStorage['token']) {
    return sessionStorage['token']
  }

  return null
}
