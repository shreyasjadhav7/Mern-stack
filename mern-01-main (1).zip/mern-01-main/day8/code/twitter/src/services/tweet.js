import axios from 'axios'
import { createUrl, getToken } from './utils'

export const createTweet = async (message, media) => {
  const response = await axios.post(
    createUrl('/tweet/'),
    { message, media },
    {
      headers: {
        token: getToken(),
      },
    }
  )
  return response.data
}

export const getAllTweets = async (message, media) => {
  const response = await axios.get(createUrl('/tweet/all'), {
    headers: {
      token: getToken(),
    },
  })
  return response.data
}

export const getRecentTweets = async (message, media) => {
  const response = await axios.get(createUrl('/tweet/recent'), {
    headers: {
      token: getToken(),
    },
  })
  return response.data
}
