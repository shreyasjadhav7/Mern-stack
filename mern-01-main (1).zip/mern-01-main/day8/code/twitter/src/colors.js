const colors = {
  blue: '#1d9bf0',
  gray: '#cccccc',
}

export default colors
