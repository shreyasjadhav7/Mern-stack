import { useState } from 'react'
import colors from '../colors'
import { toast } from 'react-toastify'
import { login } from '../services/user'
import { useNavigate } from 'react-router-dom'

const Login = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const navigate = useNavigate()

  const styles = {
    container: {
      width: '300px',
      height: '200px',
      margin: 'auto',
      position: 'absolute',
      top: '0',
      left: '0',
      right: '0',
      bottom: '0',
    },
    inputContainer: {
      margin: '20px',
    },
    input: {
      borderRadius: '20px',
    },
    buttonSignin: {
      width: '100%',
      backgroundColor: colors.blue,
      border: 'none',
      height: '40px',
      borderRadius: '20px',
      color: 'white',
      fontSize: '18px',
      fontWeight: '800',
    },
  }

  const onLogin = async () => {
    if (email.length === 0) {
      toast.warning('enter email')
    } else if (password.length === 0) {
      toast.warning('enter password')
    } else {
      const result = await login(email, password)
      if (result['status'] === 'success') {
        const user = result['data']
        sessionStorage['token'] = user['token']
        sessionStorage['username'] = user['name']
        sessionStorage['email'] = user['email']
        sessionStorage['handle'] = user['handle']

        toast.success('welcome to the application')
        navigate('/home')
      } else {
        toast.error(result['error'])
      }
    }
  }

  return (
    <div style={styles.container}>
      <h2 style={{ textAlign: 'center' }}>Whats Happening</h2>
      <h3 style={{ textAlign: 'center' }}>Join Twitter Today</h3>
      <div className="form">
        <div style={styles.inputContainer} className="form-group">
          <input
            onChange={(e) => setEmail(e.target.value)}
            style={styles.input}
            type="email"
            className="form-control"
            placeholder="email address"
          />
        </div>

        <div style={styles.inputContainer} className="form-group">
          <input
            onChange={(e) => setPassword(e.target.value)}
            style={styles.input}
            type="password"
            className="form-control"
            placeholder="xxxxxxx"
          />
        </div>
        <div style={styles.inputContainer} className="form-group">
          <button onClick={onLogin} style={styles.buttonSignin}>
            Sign in
          </button>
        </div>
      </div>
    </div>
  )
}

export default Login
