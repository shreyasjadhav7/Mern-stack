import WhatsHappening from '../components/WhatsHappening'
import MenuItems from '../components/MenuItems'
import WhoToFollow from '../components/WhoToFollow'
import CreateTweet from '../components/CreateTweet'
import Tweets from '../components/Tweets'

const Home = () => {
  return (
    <div>
      <div className="row">
        <div className="col-3">
          <MenuItems />
        </div>
        <div className="col-6">
          <CreateTweet />
          <Tweets />
        </div>
        <div className="col-3">
          <WhatsHappening />
          <WhoToFollow />
        </div>
      </div>
    </div>
  )
}

export default Home
