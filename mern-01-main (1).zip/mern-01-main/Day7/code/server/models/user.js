const mongoose = require('mongoose')

// user of the application
const UserSchema = new mongoose.Schema({
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  handle: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  bio: { type: String, default: '' },
  joinDate: { type: Date, default: new Date() },
  followings: [{ type: mongoose.Types.ObjectId, ref: 'User' }],
  followers: [{ type: mongoose.Types.ObjectId, ref: 'User' }],
  topics: [{ type: String }],
  profileImage: { type: String, default: 'default_avatar.png' },

  isDeleted: { type: Boolean, default: false },
  createdTimestamp: { type: Date, default: new Date() },
})

module.exports = mongoose.model('User', UserSchema)
