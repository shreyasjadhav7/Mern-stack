const mongoose = require('mongoose')
const { Types, Schema } = mongoose

// messages users will send and receive
const TweetSchema = new Schema({
  message: { type: String, required: true },
  user: { type: Types.ObjectId, ref: 'User' },
  media: {
    // image/video
    type: String,
    url: String,
  },
  replies: [
    {
      user: { type: Types.ObjectId, ref: 'User' },
      createdTimestamp: { type: Date, default: new Date() },
      message: { type: String, required: true },
    },
  ],
  likes: [
    {
      user: { type: Types.ObjectId, ref: 'User' },
      createdTimestamp: { type: Date, default: new Date() },
    },
  ],

  isDeleted: { type: Boolean, default: false },
  createdTimestamp: { type: Date, default: new Date() },
})

module.exports = mongoose.model('Tweet', TweetSchema)
