module.exports = {
  secrete: 'rLjd1Wik3yFV6QPTFLQv3KmjvLqTcqOu',
  db: 'localhost:27017/twitter',
  email: {
    username: 'sunbeam.sunbeaminfo@gmail.com',
    password: 'Sunbeam@Hinjewadi',
  },
}
