const express = require('express')
const utils = require('../utils')
const User = require('../models/user')
const jwt = require('jsonwebtoken')
const cryptoJs = require('crypto-js')
const config = require('../config')
const mailer = require('../mailer')

// import multer to upload a file
const multer = require('multer')

// upload a file to images directory
const upload = multer({ dest: 'images/' })

const router = express.Router()

router.post('/signup', (request, response) => {
  const { firstName, lastName, email, password, handle } = request.body

  const user = new User()
  user.firstName = firstName
  user.lastName = lastName
  user.password = cryptoJs.MD5(password)
  user.handle = handle
  user.email = email
  user.save((error, user) => {
    mailer.sendEmail(
      'Welcome to twitter',
      `
        <h1>Welcome</h1>
        <p>Dear ${firstName},</p>
        <p></p>
        <p>Thank you for joining twitter. Please spread this application.......</p>
        <p></p>
        <p>Thank you.</p>
      `,
      email,
      () => {
        response.send(utils.createResult(error, user))
      }
    )
  })
})

router.post('/signin', (request, response) => {
  const { email, password } = request.body

  User.findOne({ email: email, password: '' + cryptoJs.MD5(password) }).exec(
    (error, user) => {
      if (error) {
        response.send(utils.createError(error))
      } else if (!user) {
        response.send(utils.createError('user does not exist'))
      } else {
        // check if user already has closed his/her account
        if (user.isDeleted) {
          response.status(400)
          response.send(utils.createError('user account is deleted'))
          return
        }

        const token = jwt.sign(
          {
            name: `${user.firstName} ${user.lastName}`,
            handle: user.handle,
            email: user.email,
            id: user._id,
          },
          config.secrete
        )

        response.send(
          utils.createSuccess({
            name: `${user.firstName} ${user.lastName}`,
            handle: user.handle,
            email: user.email,
            token,
          })
        )
      }
    }
  )
})

router.post('/forgot-password', (request, response) => {
  const { email } = request.body
  User.findOne({ email: email }).exec((error, user) => {
    if (error) {
      response.send(utils.createError(error))
    } else if (!user) {
      response.send(utils.createError('user does not exist'))
    } else if (user.isDeleted) {
      response.send(utils.createError('account is closed'))
    } else {
      const otp = Math.floor(Math.random() * 1000 + 1)
      mailer.sendEmail(
        `OTP for resetting password`,
        `
        <h1>Reset Password</h1>
        <p>Dear ${user.firstName}</p>
        <p></p>
        <p>It seems like you have forgotten your password. Please use the following OTP to reset it.</p>
        <p>OTP:<b>${otp}</b> </p>
        <p></p>
        <p>Thank you.</p>
      `,
        user.email,
        () => {
          response.send(utils.createSuccess({ otp }))
        }
      )
    }
  })
})

router.get('/profile', (request, response) => {
  User.findOne(
    { _id: request.userId },
    { password: 0, createdTimestamp: 0, isDeleted: 0 }
  )
    .populate('followings', 'firstName lastName handle email')
    .populate('followers', 'firstName lastName handle email')
    .exec((error, user) => {
      response.send(utils.createResult(error, user))
    })
})

router.put('/profile', (request, response) => {
  const { firstName, lastName, bio } = request.body

  User.findOne({ _id: request.userId }).exec((error, user) => {
    if (error) {
      response.send(utils.createError(error))
    } else if (!user) {
      response.send(utils.createError('user does not exist'))
    } else {
      user.firstName = firstName
      user.lastName = lastName
      user.bio = bio
      user.save((error, user) => {
        response.send(utils.createResult(error, 'updated'))
      })
    }
  })
})

router.post('/profile-image', upload.single('photo'), (request, response) => {
  User.findOne({ _id: request.userId }).exec((error, user) => {
    if (error) {
      response.send(utils.createError(error))
    } else if (!user) {
      response.send(utils.createError('user does not exist'))
    } else {
      user.profileImage = request.file.filename
      user.save((error, user) => {
        response.send(utils.createResult(error, 'updated'))
      })
    }
  })
})

router.delete('/close', (request, response) => {
  User.findOne({ _id: request.userId }).exec((error, user) => {
    if (error) {
      response.send(utils.createError(error))
    } else if (!user) {
      response.send(utils.createError('user does not exist'))
    } else {
      user.isDeleted = true
      user.save((error, user) => {
        response.send(utils.createResult(error, 'deleted'))
      })
    }
  })
})

router.post('/toggle-follow-status/:followUserId', (request, response) => {
  ;(async () => {
    const { followUserId } = request.params

    // you can not follow yourself
    if (followUserId == request.userId) {
      response.send(utils.createError('You can not follow yourself'))
      return
    }

    User.findOne({ _id: request.userId }).exec(async (error, user) => {
      if (error) {
        response.send(utils.createError(error))
      } else if (!user) {
        response.send(utils.createError('user does not exist'))
      } else {
        // add yourself to the other user's followers list
        const followUser = await User.findOne({
          _id: followUserId,
        })

        if (!user.followings) {
          // first user to follow
          user.followings = [user]

          if (!followUser.followers) {
            followUser.followers = [request.userId]
          } else {
            // add yourself as follower
            followUser.followers.push(request.userId)
          }
        } else {
          // check if the user is following the other user already
          const tmpUsers = user.followings.filter((user) => {
            return user == followUserId
          })

          if (tmpUsers.length > 0) {
            // user exists in the followings array
            user.followings = user.followings.filter((user) => {
              return user != followUserId
            })

            followUser.followers = user.followings.filter((user) => {
              return user != request.userId
            })
          } else {
            user.followings.push(followUserId)

            if (!followUser.followers) {
              followUser.followers = [request.userId]
            } else {
              // add yourself as follower
              followUser.followers.push(request.userId)
            }
          }
        }

        // save the follow user
        await followUser.save()
        user.save((error, user) => {
          response.send(utils.createResult(error, 'updated'))
        })
      }
    })
  })()
})

module.exports = router
