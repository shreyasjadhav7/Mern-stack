const express = require('express')
const utils = require('../utils')
const Tweet = require('../models/tweet')

const router = express.Router()

router.post('/', (request, response) => {
  const { message, media } = request.body

  const tweet = new Tweet()
  tweet.message = message
  tweet.media = media
  tweet.user = request.userId
  tweet.save((error, tweet) => {
    response.send(utils.createResult(error, tweet))
  })
})

router.get('/all', (request, response) => {
  Tweet.find({ isDelete: false }, { __v: 0 })
    .populate('user', 'firstName lastName email handle profileImage')
    .populate('replies.user', 'firstName lastName email handle profileImage')
    .populate('likes.user', 'firstName lastName email handle profileImage')
    .exec((error, tweets) => {
      response.send(utils.createResult(error, tweets))
    })
})

router.get('/my', (request, response) => {
  Tweet.find({ isDelete: false, user: request.userId }, { __v: 0 }).exec(
    (error, tweets) => {
      response.send(utils.createResult(error, tweets))
    }
  )
})

router.post('/toggle-like/:id', (request, response) => {
  const { id } = request.params

  Tweet.findOne({ _id: id, isDeleted: false }).exec((error, tweet) => {
    if (error) {
      response.send(utils.createError(error))
    } else if (!tweet) {
      response.send(utils.createError('tweet does not exist'))
    } else {
      if (tweet.user == request.userId) {
        response.status(400)
        response.send(utils.createError('you can not like your tweets..'))
        return
      }

      // check if user already has liked this tweet
      const tmpLikes = tweet.likes.filter((item) => item.user == request.userId)
      if (tmpLikes.length == 0) {
        // user has not yet liked this tweet
        tweet.likes.push({
          user: request.userId,
        })
      } else {
        // as user has already liked this tweet, unlike it
        tweet.likes = tweet.likes.filter((item) => item.user != request.userId)
      }

      tweet.save((error, tweet) => {
        response.send(utils.createResult(error, 'done'))
      })
    }
  })
})

router.post('/reply/:id', (request, response) => {
  const { id } = request.params
  const { message } = request.body

  Tweet.findOne({ _id: id, isDeleted: false }).exec((error, tweet) => {
    if (error) {
      response.send(utils.createError(error))
    } else if (!tweet) {
      response.send(utils.createError('tweet does not exist'))
    } else {
      if (tweet.user == request.userId) {
        response.status(400)
        response.send(utils.createError('you can not like your tweets..'))
        return
      }

      tweet.replies.push({
        user: request.userId,
        message: message,
      })

      tweet.save((error, tweet) => {
        response.send(utils.createResult(error, 'done'))
      })
    }
  })
})

// router.post('/retweet/:id', (request, response) => {})

router.delete('/:id', (request, response) => {
  const { id } = request.params

  Tweet.findOne({ _id: id, isDeleted: false }).exec((error, tweet) => {
    if (error) {
      response.send(utils.createError(error))
    } else if (!tweet) {
      response.send(utils.createError('tweet does not exist'))
    } else {
      if (tweet.user != request.userId) {
        response.status(400)
        response.send(utils.createError('you can not delete someones tweets..'))
        return
      }

      tweet.isDeleted = true
      tweet.save((error, tweet) => {
        response.send(utils.createResult(error, 'done'))
      })
    }
  })
})

module.exports = router
