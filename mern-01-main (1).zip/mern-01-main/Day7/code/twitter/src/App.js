import WhatsHappening from './components/WhatsHappening'
import MenuItems from './components/MenuItems'

function App() {
  return (
    <div className="container">
      <div className="row">
        <div className="col">
          <MenuItems />
        </div>
        <div className="col"></div>
        <div className="col">
          <WhatsHappening />
        </div>
      </div>
    </div>
  )
}

export default App
