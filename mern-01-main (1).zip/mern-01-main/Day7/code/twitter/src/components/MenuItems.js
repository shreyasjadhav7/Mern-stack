import MenuItem from './MenuItem'

const styles = {
  buttonTweet: {
    width: '200px',
    backgroundColor: '#1d9bf0',
    color: 'white',
    border: 'none',
    borderRadius: '25px',
    height: '50px',
    marginTop: '50px',
    boxShadow: 'rgb(0 0 0 / 8%) 0px 8px 28px;',
  },
}

const MenuItems = () => {
  const menuItems = [
    {
      icon: 'home.png',
      title: 'Home',
      route: 'home',
    },
    {
      icon: 'explore.png',
      title: 'Explore',
      route: 'explore',
    },
    {
      icon: 'notifications.png',
      title: 'Notifications',
      route: 'notifications',
    },
    {
      icon: 'messages.png',
      title: 'Messages',
      route: 'messages',
    },
    {
      icon: 'bookmarks.png',
      title: 'Bookmarks',
      route: 'bookmarks',
    },

    {
      icon: 'lists.png',
      title: 'Lists',
      route: 'lists',
    },
    {
      icon: 'profile.png',
      title: 'Profile',
      route: 'profile',
    },
  ]
  return (
    <div>
      {menuItems.map((item) => {
        return <MenuItem item={item} />
      })}

      <button style={styles.buttonTweet}>Tweet</button>
    </div>
  )
}

export default MenuItems
