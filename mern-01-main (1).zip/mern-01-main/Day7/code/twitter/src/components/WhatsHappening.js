import TweetPreview from './TweetPreview'

const WhatsHappening = () => {
  const tweets = [
    {
      _id: '61eba1818381261bc44df635',
      isDeleted: false,
      createdTimestamp: '2022-01-22T06:17:34.653Z',
      replies: [],
      likes: [],
      message:
        'Some thoughts. India State of Forest Report, (ISFR) 2021.Caveat. Going to be long. Largely generic for its quality aspects hv already been widely reported. a) There should be a well defined objective behind carrying out any such effort. Forest is an ecosystem+',
      user: {
        _id: '61eb84b3974b39eb5e4cc643',
        profileImage: '5e08600dc336592b27c00d74c754f33d',
        firstName: 'amit',
        lastName: 'kulkarni',
        handle: 'pythoncpp',
        email: 'pythoncpp@gmail.com',
      },
    },
    {
      _id: '61eba251fd8b64d641416b93',
      isDeleted: false,
      createdTimestamp: '2022-01-22T06:19:59.853Z',
      replies: [
        {
          user: {
            _id: '61eb84b3974b39eb5e4cc643',
            profileImage: '5e08600dc336592b27c00d74c754f33d',
            firstName: 'amit',
            lastName: 'kulkarni',
            handle: 'pythoncpp',
            email: 'pythoncpp@gmail.com',
          },
          createdTimestamp: '2022-01-22T06:33:39.660Z',
          message: 'this is a nice tweet..',
          _id: '61eba585064fc2acca310d0b',
        },
      ],
      likes: [
        {
          user: {
            _id: '61eb84b3974b39eb5e4cc643',
            profileImage: '5e08600dc336592b27c00d74c754f33d',
            firstName: 'amit',
            lastName: 'kulkarni',
            handle: 'pythoncpp',
            email: 'pythoncpp@gmail.com',
          },
          createdTimestamp: '2022-01-22T06:30:18.376Z',
          _id: '61eba4accf0a18a9e59e1e2a',
        },
      ],
      message:
        "OMG IT'S A LAPTOP WHERE I TELL IT WHAT TO DO AND IT DOES SO WITHOUT LATENCY!?",
      user: {
        _id: '61eb96b2b41f98f3f7b689a3',
        profileImage: 'default_avatar.png',
        firstName: 'sujit',
        lastName: 'kulkarni',
        handle: 'amitk',
        email: 'amit.kulkarni@sunbeaminfo.com',
      },
    },
  ]

  const styles = {
    header: {
      color: 'rgb(15, 20, 25)',
      fontSize: '20px',
      fontWeight: '800',
      margin: '10px',
    },
    container: {
      marginTop: '10px',
      padding: '10px',
      backgroundColor: '#f7f9f9',
      borderRadius: '20px',
    },
  }
  return (
    <div style={styles.container}>
      <div style={styles.header}>What's Happening</div>

      {tweets.map((item) => {
        return <TweetPreview item={item} />
      })}
    </div>
  )
}

export default WhatsHappening
