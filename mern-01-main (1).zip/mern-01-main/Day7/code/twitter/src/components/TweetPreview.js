import moment from 'moment'

const styles = {
  date: {
    fontSize: '13px',
    color: 'rgb(83, 100, 113)',
  },
  message: {
    fontSize: '15px',
    color: 'rgb(15, 20, 25)',
    fontWeight: '700',
  },
  container: {
    padding: '10px',
  },
}

const TweetPreview = (props) => {
  const { createdTimestamp, message, user, media } = props.item

  const date = moment(createdTimestamp)
  console.log(date)

  return (
    <div style={styles.container}>
      <div style={styles.date}>{date.fromNow()}</div>
      <div style={styles.message}>{message}</div>
    </div>
  )
}

export default TweetPreview
