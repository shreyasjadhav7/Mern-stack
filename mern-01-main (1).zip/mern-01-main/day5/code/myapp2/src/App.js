import './App.css'
import Counter from './components/Counter'
import Form from './components/Form'
import Mobile from './components/Mobile'
import Person from './components/Person'
import Tweets from './components/Tweets'

function App() {
  return (
    <div className="App">
      {/* 
        react will call the function Person() with an object
        with all the properties along with the values
        
        {name: "person1"} -> props
       */}
      {/* <Person name="person1" />
      <Person name="person2" />
      <hr /> */}

      {/* <Mobile model="iPhone" company="apple" price="144000" />
      <Mobile model="Note Pro" company="Xiaomi" price="15000" />
      <Mobile model="iPad Pro" company="apple" price="115000" />
      <hr /> */}

      {/* <Tweets /> */}

      {/* <Counter /> */}

      <Form />
    </div>
  )
}

export default App
