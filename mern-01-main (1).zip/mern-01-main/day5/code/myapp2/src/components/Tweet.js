const Tweet = (props) => {
  // destructure properties
  const { id, message, user } = props.tweet

  return (
    <div style={{ paddingBottom: '20px' }}>
      <div>
        <span style={{ fontWeight: 'bold' }}>{user}</span>
      </div>
      <div>{message}</div>
    </div>
  )
}

export default Tweet
