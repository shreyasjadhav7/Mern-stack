const Mobile = (props) => {
  return (
    <div
      style={{
        display: 'inline-block',
        border: 'solid 2px black',
        padding: '10px',
        margin: '10px',
        backgroundColor: 'beige',
      }}
    >
      <h3 style={{ textAlign: 'center' }}>Mobile</h3>
      <hr />
      <div>Model: {props.model}</div>
      <div>Company: {props.company}</div>
      <div>Price: {props.price}</div>
    </div>
  )
}

export default Mobile
