import { useState } from 'react'

const Form = () => {
  const [userName, setUserName] = useState('')

  const onChangeInput = (e) => {
    // console.log('input changed')
    // console.log(`input: ${e.target.value}`)
    setUserName(e.target.value)
  }

  return (
    <div>
      User name : <input onChange={onChangeInput} />
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
      <div>{userName}</div>
    </div>
  )
}

export default Form
