// props:
// - properties: list of key-value pairs sent by the parent
// - parameter to the component's function
// - read only object

const Person = (props) => {
  console.log(props)
  return <div>{props.name}</div>
}

export default Person
