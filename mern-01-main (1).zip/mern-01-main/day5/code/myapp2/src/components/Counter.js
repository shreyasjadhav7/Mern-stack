// react hook
// - adding more functionality in react component

import { useState } from 'react'

// state:
// - component's data which can be modified
// - once modified the element rendering with the data
//   gets also rendered (updated)
// - has be defined by the same component
// - to define a state use a react hook called as useState()

// useState()
// - hook used to add something into component's state
// - accepts default value as a parameter
// - returns two values in an array
//   - the reference to the state variable
//     (which can be used to read the value from state)
//   - the reference to the function
//     (which can be used to modify the value)

const Counter = () => {
  // let counter = 0

  // state
  // - [0]

  // useState accepts the initial / default value
  const [counter, setCounter] = useState(0)

  const onIncrement = () => {
    // alert('increment')

    // increment the counter
    // counter += 1
    // console.log(`counter = ${counter}`)

    setCounter(counter + 1)
  }

  const onDecrement = () => {
    // alert('decrement')

    // decrement the counter
    // counter -= 1
    // console.log(`counter = ${counter}`)

    setCounter(counter - 1)
  }

  return (
    <div>
      <h3>Counter</h3>
      <div>counter: {counter}</div>
      <div>counter: {counter}</div>
      <div>counter: {counter}</div>
      <div>counter: {counter}</div>
      <div>counter: {counter}</div>
      <div>counter: {counter}</div>
      <div>counter: {counter}</div>
      <div>counter: {counter}</div>
      <div>counter: {counter}</div>
      <div>counter: {counter}</div>
      <div>counter: {counter}</div>
      <div>counter: {counter}</div>

      <div style={{ marginTop: '20px' }}>
        <button onClick={onIncrement}>Increment</button>
        <button onClick={onDecrement}>Decrement</button>
      </div>
    </div>
  )
}

export default Counter
