import './App.css'
import Car from './components/Car'
import Mobiles from './components/Mobiles'
import Person from './components/Person'
import Tweets from './components/Tweets'
import Welcome from './components/Welcome'

function App() {
  // return <Welcome />
  // return <Person />
  return (
    <div>
      <Welcome />
      <Person />
      <Car />
      <Mobiles />
      <Tweets />
    </div>
  )
}

export default App
