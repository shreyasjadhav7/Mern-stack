const Mobiles = () => {
  const mobiles = [
    'iphone XS',
    'Galaxy s21',
    'Note Pro',
    'iPad Pro',
    'Samsung A5',
  ]

  return (
    <div>
      <h3>Mobiles Component</h3>
      {mobiles.map((model) => {
        return <div>{model}</div>
      })}

      <ul>
        {mobiles.map((model) => {
          return <li>{model}</li>
        })}
      </ul>

      <table border="1">
        <thead>
          <tr>
            <th>Model</th>
          </tr>
        </thead>
        <tbody>
          {mobiles.map((model) => {
            return (
              <tr>
                <td>{model}</td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

export default Mobiles
