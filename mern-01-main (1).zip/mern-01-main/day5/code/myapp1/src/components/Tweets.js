const Tweets = () => {
  const tweets = [
    {
      id: 1,
      title: 'this is a test tweet 1',
      user: 'user1',
      date: '15-01-2022',
    },

    {
      id: 2,
      title: 'this is a test tweet 2',
      user: 'user2',
      date: '11-01-2022',
    },
  ]

  return (
    <div>
      <h3>Tweets Component</h3>
      <table border="1">
        <thead>
          <tr>
            <th>Id</th>
            <th>Title</th>
            <th>User</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          {tweets.map((tweet) => {
            return (
              <tr>
                <td>{tweet['id']}</td>
                <td>{tweet['title']}</td>
                <td>{tweet['user']}</td>
                <td>{tweet['date']}</td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

export default Tweets
