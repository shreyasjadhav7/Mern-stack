// first component
const Welcome = () => {
  return <h1>this is a first react component</h1>
}

export default Welcome
