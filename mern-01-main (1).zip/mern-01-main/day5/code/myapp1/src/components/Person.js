const Person = () => {
  return (
    <div>
      <h3>Person Component</h3>
      <div>Name: Person 1 </div>
      <div>Address: Pune</div>
      <div>Phone: +91234335345</div>
      <div>Email: person1@test.com</div>
    </div>
  )
}

export default Person
