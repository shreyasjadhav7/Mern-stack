const Car = () => {
  const car = {
    model: 'i20',
    company: 'hyudai',
    price: 15.5,
  }

  // const model = 'i20'

  return (
    <div>
      <h3>Car Component</h3>

      {/* interpolation */}
      <div>Model: {car.model}</div>
      <div>Company: {car.company}</div>
      <div>Price: {car.price}</div>
      <div></div>
    </div>
  )
}

export default Car
