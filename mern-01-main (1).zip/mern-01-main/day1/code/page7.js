// function name is considered as a reference of type function

// function definition
function function1() {
  console.log('inside function 1')
}

// function call
// function1()

// console.log(`function1 = ${function1}`)
// console.log(`function1 type = ${typeof function1}`)

// function2 is considered as a reference
// which will point to an object of type function
const function2 = function () {
  console.log(`inside function2`)
}

// function2()

// arrow/lambda function
const function3 = () => {
  console.log(`inside function3`)
}

// function3()

// function alias
// - another name given to existing function
// - reference to another function
const myFunction = function1

function1()
myFunction()
