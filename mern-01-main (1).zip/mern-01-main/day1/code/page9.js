function add(p1, p2) {
  console.log(`addition = ${p1 + p2}`)
}

const subtract = (p1, p2) => {
  console.log(`subtraction = ${p1 - p2}`)
}

function executor(param) {
  console.log(`param = ${param}, type = ${typeof param}`)

  if (typeof param == 'function') {
    // call the function
    param(10, 20)
  }
}

// executor(10)
// executor('test')
executor(add)
console.log()

executor(subtract)
console.log()

// division function (parameter function) is
// called as a callback function
executor((p1, p2) => {
  console.log(`division = ${p1 / p2}`)
})
