// const: constant -> immutable
const num = 100

// constant can not be updated
// num = 102

// number
const num1 = 100
console.log(`num1 = ${num1}, type = ${typeof num1}`)

// number
const salary = 24.5
console.log(`salary = ${salary}, type = ${typeof salary}`)

// string
const firstName = 'steve'
console.log(`first name = ${firstName}, type = ${typeof firstName}`)

// string
const lastName = 'jobs'
console.log(`last name = ${lastName}, type = ${typeof lastName}`)

// string
const address = `USA`
console.log(`address = ${address}, type = ${typeof address}`)

// boolean
const canVote = true
console.log(`canVote = ${canVote}, type = ${typeof canVote}`)

// object
// collection of key-value pairs
// keys: name, address -> string
// values: person1, pune
const person = {
  name: 'person1',
  address: 'pune',
}
console.log(`person = ${person}, type = ${typeof person}`)

// undefined
let myVar
console.log(`myVar = ${myVar}, type = ${typeof myVar}`)

// let: mutable -> can be updated
let num2 = 100
num2 = 200
