// creating an object using constructor function
// every object in JS is created using Object directly or indirectly

// constructor function
// - used to create one more more objects easily
// - looks similar to a constructor in other languages (Java, c++)

// constructor function
function Person(name, address, age) {
  // this:
  // - is currently referred object
  // - is a reference
  this.name = name
  this.address = address
  this.age = age
}

const p1 = new Person('person1', 'pune', 30)
console.log(p1)

const p2 = new Person('person2', 'mumbai', 10)
console.log(p2)

// constructor function to create mobile objects
function Mobile(model, company, price) {
  this.model = model
  this.company = company
  this.price = price
}

const m1 = new Mobile('iPhone 13 Pro Max', 'Apple', 179000)
console.log(m1)
console.log(`m1 = ${m1}`)
