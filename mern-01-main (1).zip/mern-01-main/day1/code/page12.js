// de-structuring

function function1() {
  const person1 = {
    name: 'person1',
    address: 'pune',
    age: 30,
  }

  console.log(`name = ${person1.name}`)
  console.log(`address = ${person1.address}`)
  console.log(`age = ${person1.age}`)
}

// function1()

function function2() {
  const person1 = {
    name: 'person1',
    address: 'pune',
    age: 30,
  }

  // JS will create 3 variables named name, address and age
  // and will copy the values from person1 values
  // imp: make sure the variable name and object key is same (case sensitive)
  const { name, age, address } = person1

  console.log(`name = ${name}`)
  console.log(`address = ${address}`)
  console.log(`age = ${age}`)
}

function2()
