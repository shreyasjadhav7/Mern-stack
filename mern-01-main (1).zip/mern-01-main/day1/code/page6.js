// number
const num1 = 100

// number
let num2 = num1

console.log(`num1 = ${num1}, num2 = ${num2}`)
num2 = 200
console.log(`num1 = ${num1}, num2 = ${num2}`)

// object is always considered as reference type

const person1 = {
  name: 'person1',
  address: 'pune',
}

const person2 = person1
console.log(person1)
console.log(person2)

person2.name = 'person1 changed'
person2.address = 'mumbai'

console.log(person1)
console.log(person2)
