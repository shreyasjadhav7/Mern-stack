// creating an object using JSON syntax

// person1 is a constant reference
const person1 = {
  name: 'person1',
  address: 'pune',
  age: 30,
  canVote: true,
}

console.log(person1)

// person1 gets converted to string value
// and gets concatanated with "person1 = "
console.log(`person1 = ${person1}`)

// person1's properties/keys can be modified
person1.address = 'mumbai'
person1.salary = 20

console.log(person1)

// person1 as a reference can not be set to another object
// person1 = { name: 'person2' }
