// Array
// - collection of object/values

function function1() {
  // array of numbers
  const numbers = [10, 20, 30, 40, 50]
  console.log(numbers)
}

// function1()

function function2() {
  // array of numbers
  const numbers = [10, 20, 30, 40, 50]

  // traditional for loop
  for (let index = 0; index < numbers.length; index++) {
    // getting the value at indexth location
    const value = numbers[index]
    console.log(`value at ${index} = ${value}`)
  }
}

// function2()

function function3() {
  // array of numbers
  const numbers = [10, 20, 30, 40, 50]

  // for..of loop
  for (const value of numbers) {
    console.log(`value = ${value}`)
  }
}

// function3()

function function4() {
  // array of numbers
  const numbers = [10, 20, 30, 40, 50]

  // for..each loop
  numbers.forEach((value) => {
    console.log(`value = ${value}`)
  })
}

function4()
