// Array

function function1() {
  const numbers = [10, 20, 30, 40, 50]
  console.log(numbers)

  // add a new value to the end of the array
  numbers.push(60)
  console.log(numbers)
}

// function1()

function function2() {
  const numbers = [10, 20, 30, 40, 50]
  console.log(numbers)

  // remove the last value
  numbers.pop()
  console.log(numbers)
}

// function2()

function function3() {
  const numbers = [10, 20, 30, 40, 50]
  console.log(numbers)

  // remove a value in between
  // - param1: index
  // - count: number of values to be removed from index
  numbers.splice(2, 2)
  console.log(numbers)
}

// function3()

function function4() {
  const numbers = [1, 2, 3, 4, 5]

  // get square of every number and store in squares array
  // const squares = []
  // for (const value of numbers) {
  //   squares.push(value ** 2)
  // }

  // get square of every number and store in squares array
  const squares = numbers.map((value) => {
    return value ** 2
  })

  // get cube of every number and store in cubes array
  const cubes = numbers.map((value) => {
    return value ** 3
  })

  console.log(numbers)
  console.log(squares)
  console.log(cubes)
}

// function4()

function myMap(array, callback) {
  const results = []
  for (const value of array) {
    const result = callback(value)
    results.push(result)
  }

  return results
}

// const results = myMap([1, 2, 3, 4, 5], (value) => {
//   return value ** 2
// })

// console.log(`squares = ${results}`)

function function5() {
  const temperatures = [97, 98, 99, 96, 95, 92]
  const tempCelsius = temperatures.map((temperature) => {
    return (temperature - 32) * (5 / 9)
  })

  console.log(tempCelsius)
}

// function5()

function function6() {
  const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

  // get only the even numbers from numbers collection
  // const evenNumbers = []
  // for (const value of numbers) {
  //   if (value % 2 == 0) {
  //     evenNumbers.push(value)
  //   }
  // }

  const evenNumbers = numbers.filter((value) => {
    return value % 2 == 0
  })

  const oddNumbers = numbers.filter((value) => {
    return value % 2 != 0
  })

  console.log(numbers)
  console.log(evenNumbers)
  console.log(oddNumbers)
}

function6()
