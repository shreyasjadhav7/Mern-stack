// hello world application

// print hello world on console
console.log('hello world...')
