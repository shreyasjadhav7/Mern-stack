function function1() {
  const person1 = {
    name: 'person1',
    address: 'pune',
    age: 30,
  }

  // pointing to the existing object
  // shallow copy
  // const person2 = person1

  // copy all the attributes from existing object
  // deep copy
  // const person2 = {
  //   name: person1.name,
  //   address: person1.address,
  //   age: person1.age,
  //   email: 'person1@test.com'
  // }

  // spread operator
  // deep copy
  // get all the attributes from person1 and
  // add new attribute email
  const person2 = { ...person1, email: 'person1@test.com' }

  console.log(person1)
  console.log(person2)

  person2.address = 'mumbai'
  console.log(person1)
  console.log(person2)
}

// function1()

// function add1(p1, p2) {
//   console.log(`addition = ${p1 + p2}`)
// }

// function add2(p1, p2, p3) {
//   console.log(`addition = ${p1 + p2 + p3}`)
// }

// add1(10, 20)
// add2(10, 20, 30)

// ...numbers means rest operator
// all the parameters passed to the function
// variable number arguments functions
function add(...numbers) {
  let addition = 0
  for (const value of numbers) {
    addition += value
  }

  console.log(`${numbers.join(' + ')} = ${addition}`)
}

// add(10, 20)
// add(10, 20, 30)
// add(10, 20, 30, 40)
// add(10, 20, 30, 40, 50)
