// creating an object using Object
// Object:
// - is root function provided by JS
// - used to create an object

// create a person object
const person1 = new Object()

// add required properties
person1.name = 'person1'
person1.address = 'pune'
person1.age = 30
person1.canVote = true

console.log(person1)

// create a tweet object
const tweet = new Object()

// add required properties
tweet.createdBy = 'user1'
tweet.message = 'hi! welcome to MERN'
tweet.createdOn = new Date()

console.log(tweet)
