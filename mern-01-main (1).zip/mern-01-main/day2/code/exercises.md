## exercise 1

- create a new collection named: user
- add a new user with following information
  - name: user1
  - address: pune
  - phone: 23432224
  - password: test
  - email: user1@test.com
- find all the records
