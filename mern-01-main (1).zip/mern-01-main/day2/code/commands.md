## database related operations

- **open mongo shell**

  ```bash
    > mongo
  ```

- **show the list of databases**

  ```bash
    > show dbs
  ```

- **create and use the database**

  ```bash
    > use mydb
  ```

- **show the current database that is selected**

  ```bash
    > db
  ```

- **show statistics of a db**

  ```bash
    > db.stats()
  ```

---

## collection related operations

- **show the list of existing collections**

  ```bash
    > show collections
  ```

- **create a new collection**

  ```bash
    > db.createCollection('product')
  ```

- **remove the collection**

```bash
  > db.product.drop()
```

- **rename existing collection**

```bash
  > db.product.renameCollection('newProduct')
```

---

## document related operations

- **insert a new document into a collection**

```bash
  > db.product.insert({title: "product1", price: 2000, description: "test product 1"})
```

- **insert multiple documents (records)**

```bash
  > db.product.insertMany([
      {title: "product 2", price: 3000, description: "test product"},
      {title: "product 3", price: 4000, description: "test product "},
      {title: "product 4", price: 4000, description: "test product"},
      {title: "product 5", price: 4000, description: "test product"},
      {title: "product 6", price: 4000, description: "test product"},
      {title: "product 7", price: 4000, description: "test product"},
      {title: "product 8", price: 4000, description: "test product"},
      {title: "product 9", price: 4000, description: "test product"},
      {title: "product 10", price: 4000, description: "test product"},
      {title: "product 11", price: 4000, description: "test product"},
      {title: "product 12", price: 4000, description: "test product"},
      {title: "product 13", price: 4000, description: "test product"},
      {title: "product 14", price: 4000, description: "test product"},
      {title: "product 15", price: 4000, description: "test product"},
      {title: "product 16", price: 4000, description: "test product"},
      {title: "product 17", price: 4000, description: "test product"},
      {title: "product 18", price: 4000, description: "test product"},
      {title: "product 19", price: 4000, description: "test product"},
      {title: "product 20", price: 4000, description: "test product"},
      {title: "product 21", price: 4000, description: "test product"},
    ])
```

- **select all documents**

```bash
  > db.product.find()
```

- **get the count of all documents in a collection**

```bash
  > db.product.find().count()
```

- **check if the find can return more records**

```bash
  > db.product.find().hasNext()
```

- **get the next set of records**

```bash
  > db.product.find().next()
```

- **find only limited records**

```bash
  # get first 5 records
  > db.product.find().limit(5)
```

- **skip records**

```bash
  # skip first 5 records
  > db.product.find().skip(5)
```

- **pagination technique**

```bash
  > count = 3

  # get the first page data
  > db.product.find().skip(count * 0).limit(count)

  # get the second page data
  > db.product.find().skip(count * 1).limit(count)

  # get the third page data
  > db.product.find().skip(count * 2).limit(count)
```

- **pretty format result**

```bash
  > db.product.find().pretty()
```

- **filtering records**

```bash
  # find the product named "product 7"
  > db.product.find({title: "product 7"})

  # find the product with price 4000
  > db.product.find({price: 4000})

  # find the product with price > 3000
  > db.product.find({price: { $gt: 3000 }})

  # find the product with price >= 3000
  > db.product.find({price: { $gte: 3000 }})

  # find the product with price < 3000
  > db.product.find({price: { $lt: 3000 }})

  # find the product with price <= 3000
  > db.product.find({price: { $lte: 3000 }})

  # find the product with price is 3000 or 2000
  > db.product.find({price: { $in: [2000, 3000] }})

  # find the product with price is not 3000 or not 2000
  > db.product.find({price: { $nin: [2000, 3000] }})

  # find the products having name as product 6 or price as 2000
  > db.product.find(
      {
        $or: [
          {title: "product 6"},
          {price: 2000}
        ]
      }
    )

  # find the products having name as product 6 and price as 2000
  > db.product.find(
      {
        $and: [
          {title: "product 6"},
          {price: 2000}
        ]
      }
    )
```

- **query projection (selecting required attributes/fields)**

```bash
  # select title of every product (including _id)
  > db.product.find({}, {title: 1})
  > db.product.find({}, {price: 0, description: 0})

  # select title and price of every product
  > db.product.find({}, {title: 1, price: 1})
  > db.product.find({}, {description: 0})

  # select title of every product (excluding _id)
  > db.product.find({}, {title: 1, _id: 0})
```

- **update documents**

```bash
  # update a product having id, with new title, price, description
  > db.product.update(
      {_id: ObjectId('61d14117b4044b4a7e194703')},
      {
        title: 'product 1 updated',
        price: 2000,
        description: 'test product'
      }
    )

  # update a product having id, with new price
  > db.product.update(
      {_id: ObjectId('61d14117b4044b4a7e194703')},
      { $set: { price: 4000 } }
    )

  # update all products having price 4000 to new price 6000
  > db.product.updateMany({price: 4000}, {$set: {price: 6000}})
```

- **remove existing objects**

```bash
  # delete an object having an _id
  > db.product.remove({"_id" : ObjectId("61d14117b4044b4a7e194703")})
  > db.product.deleteOne({"_id" : ObjectId("61d14117b4044b4a7e194703")})

  # delete all products having price 6000
  > db.product.deleteMany({price: 6000})
```
