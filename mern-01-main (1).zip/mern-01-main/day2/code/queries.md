## relational operators

**find all SALESMAN**

```
> db.emp.find({job: 'SALESMAN'})
```

**find all CLERK**

```

```

**find all emps in dept 30**

```

```

**find all emps not in dept 30**

```

```

**find all emps whose sal < 2500**

```

```

**find all emps who have comm field**

```

```

**find all emps who do not have comm field**

```

```

**find all emps who have comm = null**

```

```

**find all emps whose name starts with 'M'**

```

```

**find all emps whose name contains 'A' twice**

```

```

**find all emps whose name ends with S, the comparison should be case insensitive**

```

```

**find emp whose name is JAMES or MILLER**

```

```

**find emp who is not SALESMAN, MANAGER or PRESIDENT**

```

```

---

## logical operators

**find emps having sal more than 4000 or they are ANALYST**

```

```

**find emps which are not in dept 20 and not SALESMAN**

```

```

**find all MANAGER in dept 30 or all SALESMAN in dept 30 having sal <= 1500**

```

```

---

## projection

**display emp details \_id, ename, job and sal**

```

```

**display emp details except mgr, sal, comm, job**

```

```

**display emp details ename, mgr**

```

```

**display emp details \_id, ename, deptno, sal; but skip mgr, job, comm**

```

```

**display emp details ename, deptno, sal without \_id**

```

```

**display emp ename where sal >= 2500**

```

```

---

## Aggregation pipeline

**sum of sal per job**

```

```

**avg of sal per dept**

```

```

**print total sal, avg sal, max sal, min sal per job**

```

```

**print all jobs for which total sal is more than 5700**

```

```

**display depts total sal in desc order**

```

```

**find the dept that spends max on sal**

```

```

**display ename, deptno & sal of all emps whose sal >= 2500**

```

```

**display ename, deptno & sal of all emps whose sal >= 2500 in the DESC order of sal**

```

```

**analyse data per dept per job [find the count of emps per deptno]**

```

```

**find the job with max AVG sal**

```

```

**find number of managers, analysts and clerks in company**

```

```

**print ename and dept name and dept location**

```

```

**print depts and emps in that dept**

```

```

**print emp name and his manager details [final result -> { ename: '', manager: '' }]**

```

```
