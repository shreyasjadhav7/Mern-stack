## Express

- installation of utilities

```bash
# for windows
> npm install -g yarn nodemon

# for linux and mac
> sudo npm install -g yarn nodemon
```

- installation of express

```bash
> npm install express
> yarn add express
```
