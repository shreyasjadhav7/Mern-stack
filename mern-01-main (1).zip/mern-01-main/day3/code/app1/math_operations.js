// custom module

function add(p1, p2) {
  console.log(`${p1} + ${p2} = ${p1 + p2}`)
}

function subtract(p1, p2) {
  console.log(`${p1} - ${p2} = ${p1 - p2}`)
}

const pi = 3.14

// function alias
// function reference
// const myadd = add

// export all the entities for other modules
module.exports = {
  // add is the function alias
  add: add,

  // subtract is the function alias
  subtract: subtract,

  // constant
  pi: pi,
}
