// import from math_operations
const mathOperations = require('./math_operations')

mathOperations.add(10, 20)
mathOperations.subtract(20, 10)

console.log(`pi = ${mathOperations.pi}`)
