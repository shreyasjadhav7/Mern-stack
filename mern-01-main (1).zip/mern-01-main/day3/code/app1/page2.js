// import os module
const os = require('os')

console.log(`os platform  = ${os.platform()}`)
console.log(`home directory = ${os.homedir()}`)
console.log(
  `ram size = ${os.totalmem()} Bytes, ${os.totalmem() / (1024 * 1024 * 1024)}GB`
)
console.log(`number of CPUs = ${os.cpus().length}`)
