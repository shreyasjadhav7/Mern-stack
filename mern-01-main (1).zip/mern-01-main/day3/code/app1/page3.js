// import file system module
const fs = require('fs')

// synchronous
function writeContentsSync() {
  fs.writeFileSync(
    './myfile.txt',
    'India is my country. All indians are my brothers and sisters.'
  )
}

// writeContentsSync()

// synchronous/sequential/serial/blocking operation
function readContentsSync() {
  // first operation
  console.log('file reading started')

  // blocking API: blocks the next line till its execution
  const data = fs.readFileSync('./myfile.txt')
  console.log('file reading finished')
  console.log(`data: ${data}`)
  // console.log(data)

  // second operation
  console.log('math operation started')
  const answer = 234923234242423234 * 2423424242342424234243
  console.log('math operation finished')
  console.log(`answer = ${answer}`)
}

// readContentsSync()

// asynchronous/non-blocking/parallel/non-sequential operation
function readContentsAsync() {
  // first operation
  console.log('file reading started')

  // 1st param: file path
  // 2nd param: callback function

  // this function does not block the next line from its execution
  // the reading operation and math operation will execute in parallel
  fs.readFile('./myfile.txt', (error, data) => {
    // file reading finished
    console.log('file reading finished')
    console.log(`data = ${data}`)
  })

  // second operation
  console.log('math operation started')
  const answer = 234923234242423234 * 2423424242342424234243
  console.log('math operation finished')
  console.log(`answer = ${answer}`)
}

readContentsAsync()
