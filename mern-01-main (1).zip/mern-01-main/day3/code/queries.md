## relational operators

**find all SALESMAN**

```
> db.emp.find({job: 'SALESMAN'})
```

**find all CLERK**

```

```

**find all emps in dept 30**

```

```

**find all emps not in dept 30**

```

```

**find all emps whose sal < 2500**

```

```

**find all emps who have comm field**

```

```

**find all emps who do not have comm field**

```

```

**find all emps who have comm = null**

```

```

**find all emps whose name starts with 'M'**

```

```

**find all emps whose name contains 'A' twice**

```

```

**find all emps whose name ends with S, the comparison should be case insensitive**

```

```

**find emp whose name is JAMES or MILLER**

```

```

**find emp who is not SALESMAN, MANAGER or PRESIDENT**

```

```

---

## logical operators

**find emps having sal more than 4000 or they are ANALYST**

```
> db.emp.find({$or: [
    {sal: {$gt: 4000}},
    {job: 'ANALYST'}
  ]})
```

**find emps which are not in dept 20 and not SALESMAN**

```
> db.emp.find({$and: [
    {deptno: {$ne: 20}},
    {job: {$ne: 'SALESMAN'}}
  ]})
```

```
> db.emp.find({
    deptno: {$ne: 20},
    job: {$ne: 'SALESMAN'}
  })
```

**find all MANAGER in dept 30 or all SALESMAN in dept 30 having sal <= 1500**

- [ MANAGER in dept 30 ] or
- [ SALESMAN in dept 30 having sal <= 1500 ]

```
> db.emp.find({ $or: [
  {
    $and: [
      { job: 'MANAGER' },
      { deptno: 30 }
    ]
  },
  {
    $and: [
      { job: 'SALESMAN' },
      { deptno: 30 },
      { sal: { $lte: 1500 } }
    ]
  }
]})
```

```
> db.emp.find({ $or: [
  {
    job: 'MANAGER',
    deptno: 30
  },
  {
    job: 'SALESMAN',
    deptno: 30,
    sal: { $lte: 1500 }
  }
]})
```

---

## projection

**display emp details \_id, ename, job and sal**

```

```

**display emp details except mgr, sal, comm, job**

```

```

**display emp details ename, mgr**

```

```

**display emp details \_id, ename, deptno, sal; but skip mgr, job, comm**

```

```

**display emp details ename, deptno, sal without \_id**

```

```

**display emp ename where sal >= 2500**

```

```

---

## Aggregation pipeline

**sum of sal per job**

```
> db.emp.aggregate([
    // stage1: get the data grouped by job
    {
      $group: {
        _id: '$job',
        sum: {$sum: '$sal'}
      }
    }
  ])
```

**avg of sal per dept**

```
> db.emp.aggregate([
    // stage1: get the data grouped by deptno
    {
      $group: {
        _id: '$deptno',
        averageSalary: {$avg: '$sal'}
      }
    }
  ])
```

**print total sal, avg sal, max sal, min sal per job**

```
> db.emp.aggregate([
    // stage1: get the data grouped by job
    {
      $group: {
        _id: '$job',
        totalSalary: { $sum: '$sal' },
        averageSalary: { $avg: '$sal' },
        minSalary: { $min: '$sal' },
        maxSalary: { $max: '$sal' },
      }
    }
  ])
```

**print all jobs for which total sal is more than 5700**

```
> db.emp.aggregate([
    // stage1: get the data grouped by job
    {
      $group: {
        _id: '$job',
        totalSalary: {$sum: '$sal'}
      }
    },

    // stage2: match the condition [totalSalary > 5700]
    {
      $match: {
        totalSalary: { $gt: 5700 }
      }
    }
  ])
```

**display depts total sal in desc order**

```
> db.emp.aggregate([
    // stage1: get the data grouped by deptno
    {
      $group: {
        _id: '$deptno',
        totalSalary: {$sum: '$sal'}
      }
    },

    // stage2: get the records sorted in desc order
    {
      $sort: {
        totalSalary: -1
      }
    }
  ])
```

**find the dept that spends max on sal**

```
> db.emp.aggregate([
    // stage1: get the data grouped by deptno
    {
      $group: {
        _id: '$deptno',
        totalSalary: {$sum: '$sal'}
      }
    },

    // stage2: get the records sorted in desc order
    {
      $sort: {
        totalSalary: -1
      }
    },

    // stage3: limit the number of records to 1
    {
      $limit: 1
    }
  ])
```

**find the dept that spends minimum on sal**

```
> db.emp.aggregate([
    // stage1: get the data grouped by deptno
    {
      $group: {
        _id: '$deptno',
        totalSalary: {$sum: '$sal'}
      }
    },

    // stage2: get the records sorted in desc order
    {
      $sort: {
        totalSalary: 1
      }
    },

    // stage3: limit the number of records to 1
    {
      $limit: 1
    }
  ])
```

**display ename, deptno & sal of all emps whose sal >= 2500**

```
> db.emp.find(
    { sal: { $gte: 2500 } },
    { ename:1, deptno: 1, _id: 0, sal: 1 })
```

```
> db.emp.aggregate([
    // stage1: find the emp having sal >= 2500
    {
      $match: {
        sal: { $gte: 2500 }
      }
    },

    // stage2: select the required columns
    {
      $project: {
        ename:1, deptno: 1, _id: 0, sal
      }
    }
  ])
```

**display ename, deptno & sal of all emps whose sal >= 2500 in the DESC order of sal**

```
> db.emp.aggregate([
    // stage1: find the emp having sal >= 2500
    {
      $match: {
        sal: { $gte: 2500 }
      }
    },

    // stage2: sort the records by sal in desc order
    {
      $sort: {
        sal: -1
      }
    },

    // stage3: select the required columns
    {
      $project: {
        ename:1, deptno: 1, _id: 0, sal: 1
      }
    }
  ])
```

**analyse data per dept per job [find the count of emps per deptno per job]**

```
> db.emp.aggregate([
    // stage1: find the emp per dept per job
    {
      $group: {
        _id: {
          deptno: '$deptno',
          job: '$job'
        },
        totalEmployees: {
          $sum: 1
        }
      }
    }
  ])
```

**find the job with max AVG sal**

```
> db.emp.aggregate([
    // stage1: find the emp per dept per job
    {
      $group: {
        _id: '$job',
        averageSalary: {
          $avg: '$sal'
        }
      }
    },
    // stage2: sort the records with desc order
    {
      $sort: {
        averageSalary: -1
      }
    },
    // stage3: limit the result to 1 record
    {
      $limit: 1
    }
  ])
```

**find number of managers, analysts and clerks in company**

```
> db.emp.aggregate([
    // stage1: match the job for getting managers, analysts and clerks
    {
      $match: {
        job: { $in: ['MANAGER', 'ANALYST', 'CLERK'] }
      }
    },

    // stage2: find the emp per dept per job
    {
      $group: {
        _id: '$job',
        count: {
          $sum: 1
        }
      }
    }
  ])
```

**print ename and dept name and dept location**

```
> db.emp.aggregate([
    // stage1: lookup the information from dept collection
    {
      $lookup: {
        from: 'dept',           // get the related dept record
        localField: 'deptno',   // the field which is used for finding the dept from dept collection
        foreignField: '_id',    // the dept field which matches with deptno of emp collection
        as: 'department'
      }
    },

    // stage2: unwind the array into object
    {
      $unwind: '$department'
    },

    // stage3: add new fields for dept name and location
    {
      $addFields: {
        deptName: '$department.dname',
        deptLocation: '$department.loc'
      }
    },

    // stage4: select required fields
    {
      $project: {
        deptName: 1, deptLocation: 1, ename: 1, _id: 0
      }
    }
  ])
```

**print depts and emps in that dept**

```
> db.dept.aggregate([
    // stage1: find all employees belong to the dept
    {
      $lookup: {
        from: 'emp',           // get the related dept record
        localField: '_id',   // the field which is used for finding the dept from dept collection
        foreignField: 'deptno',    // the dept field which matches with deptno of emp collection
        as: 'employees'
      }
    },

    // stage2: get only dept name and employee name
    {
      $project: {
        dname: 1, 'employees.ename': 1, _id: 0
      }
    }
  ])
```

**print emp name and his manager details [final result -> { ename: '', manager: '' }]**

```
> db.emp.aggregate([
    // stage1: lookup the information from dept collection
    {
      $lookup: {
        from: 'emp',           // get the related dept record
        localField: 'mgr',   // the field which is used for finding the dept from dept collection
        foreignField: '_id',    // the dept field which matches with deptno of emp collection
        as: 'manager'
      }
    },

    // stage2: unwind the array into object
    {
      $unwind: '$manager'
    },

    // stage3: add new fields for dept name and location
    {
      $addFields: {
        managerName: '$manager.ename',
      }
    },

    // stage4: select required fields
    {
      $project: {
        ename: 1, managerName: 1, _id: 0
      }
    }
  ])
```
