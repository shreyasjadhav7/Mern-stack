// import express
const express = require('express')

// import mongodb driver used to connect to the mongodb
const MongoClient = require('mongodb').MongoClient

// create a new express application
const app = express()

// add a route to process the request
app.get('/emp', (request, response) => {
  // connect to the mongodb running on the local machine
  MongoClient.connect('mongodb://localhost:27017/mydb', (err, client) => {
    // check if the connection is valid
    if (err) throw err

    // open the connection with db
    const db = client.db('mydb')

    // perform the find operation
    db.collection('emp')
      .find()
      .toArray((err, result) => {
        // if error while getting documents from emp collection
        if (err) throw err

        // send the emp documents to the client
        response.send(result)
      })
  })
})

// add a route to process the request
app.get('/mgr', (request, response) => {
  // connect to the mongodb running on the local machine
  MongoClient.connect('mongodb://localhost:27017/mydb', (err, client) => {
    // check if the connection is valid
    if (err) throw err

    // open the connection with db
    const db = client.db('mydb')

    // perform the find operation
    db.collection('emp')
      .find({ job: 'MANAGER' })
      .toArray((err, result) => {
        // if error while getting documents from emp collection
        if (err) throw err

        // send the emp documents to the client
        response.send(result)
      })
  })
})

// start the application on port 4000
app.listen(4000, '0.0.0.0', () => {
  console.log('server started on port 4000')
})
