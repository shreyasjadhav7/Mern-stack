// import express
const express = require('express')

// create a new express application
const app = express()

// method: GET, path: /
// route: mapping of method and path
app.get('/', (request, response) => {
  // send the response to the client
  response.send('hello from server')
})

// method:POST path: /user/signup
app.post('/user/signup', (request, response) => {
  // send response to the client
  response.send('user signup is working fine')
})

// method:POST path: /user/signin
app.post('/user/signin', (request, response) => {
  // send response to the client
  response.send('user signin is working fine')
})

// method: GET path: /tweeet
app.get('/tweet', (request, response) => {
  // send response to the client
  response.send('list of tweets')
})

// start the app on port 4000
app.listen(4000, '0.0.0.0', () => {
  console.log(`express server started successfully`)
})
