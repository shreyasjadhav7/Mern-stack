import Page1 from './pages/Page1'
import Signup from './pages/Signup'

// get the dependency added for react-toastify
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import Signin from './pages/Signin'
import Home from './pages/Home'

// import the react-router for routing between the components
import {
  BrowserRouter,
  Link,
  Route,
  Routes,
  useNavigate,
} from 'react-router-dom'

const Component1 = () => {
  return <h1 className="page-title">Component 1</h1>
}

const Component2 = () => {
  return <h1 className="page-title">Component 2</h1>
}

const Component3 = () => {
  return <h1 className="page-title">Component 3</h1>
}

const AuthorizedUser = () => {
  // look for the token
  const token = sessionStorage['token']

  if (token && token.length > 0) {
    // user is already signed in, so go to Home
    return <Home />
  } else {
    // use is not yet signed in, so go to signin component
    return <Signin />
  }
}

function App() {
  return (
    <div className="container">
      <BrowserRouter>
        {/* <Link to="/c1">Component 1</Link>
        <Link to="/c2">Component 2</Link>
        <Link to="/c3">Component 3</Link> */}

        <Routes>
          <Route path="/" element={<AuthorizedUser />} />

          <Route path="/page1" element={<Page1 />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/signin" element={<Signin />} />
          <Route path="/home" element={<Home />} />

          <Route path="/c1" element={<Component1 />} />
          <Route path="/c2" element={<Component2 />} />
          <Route path="/c3" element={<Component3 />} />
        </Routes>
      </BrowserRouter>

      <ToastContainer />
    </div>
  )
}

export default App
