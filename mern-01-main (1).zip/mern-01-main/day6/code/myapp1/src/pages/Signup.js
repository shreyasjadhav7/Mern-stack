import { useState } from 'react'

// imoprt axios to make the APIs calls
import axios from 'axios'

// import the toast function to show a toast
import { toast } from 'react-toastify'
import { Link, useNavigate } from 'react-router-dom'

const Signup = () => {
  const url = 'http://localhost:4000/user/signup'

  // initially all the user input values will be empty
  const [userName, setUserName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  // use this hook to navigate from one component to another
  const navigate = useNavigate()

  const signupUser = () => {
    if (userName.length === 0) {
      toast.warning('please enter user name')
    } else if (email.length === 0) {
      toast.warning('please enter email')
    } else if (password.length === 0) {
      toast.warning('please enter password')
    } else {
      // call the POST api
      axios
        .post(url, {
          name: userName,
          email,
          password,
        })
        .then((response) => {
          // read the response sent by the server
          const result = response.data
          if (result['status'] === 'success') {
            toast.success('new user signed up')

            // go to the signin component
            navigate('/signin')
          } else {
            toast.error('error while signing up the user')
          }
        })
        .catch((error) => {
          toast.error(error)
        })
    }
  }

  return (
    <div>
      <h1 className="page-title">Signup</h1>

      <div className="form-group">
        <div className="mb-3">
          <label className="form-label">Full name</label>
          <input
            onChange={(e) => {
              setUserName(e.target.value)
            }}
            type="text"
            className="form-control"
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Email address</label>
          <input
            onChange={(e) => {
              setEmail(e.target.value)
            }}
            type="email"
            className="form-control"
            placeholder="name@example.com"
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Password</label>
          <input
            onChange={(e) => {
              setPassword(e.target.value)
            }}
            type="password"
            className="form-control"
            placeholder="*******"
          />
        </div>

        <div className="mb-3">
          <p>
            Already have an account? Sign in <Link to="/signin">here</Link>.
          </p>
          <button onClick={signupUser} className="btn btn-success">
            Signup
          </button>
        </div>
      </div>
    </div>
  )
}

export default Signup
