import { useState } from 'react'
import { toast } from 'react-toastify'
import axios from 'axios'
import { Link, useNavigate } from 'react-router-dom'

const Signin = () => {
  const url = 'http://localhost:4000/user/signin'

  // get user input to make the signin api call
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  // use the hook to navigate
  const navigate = useNavigate()

  const onSignin = () => {
    if (email.length === 0) {
      toast.warning('please enter email')
    } else if (password.length === 0) {
      toast.warning('please enter password')
    } else {
      // call the signin api
      axios
        .post(url, {
          email,
          password,
        })
        .then((response) => {
          // read the json response sent by server
          const result = response.data

          if (result['status'] === 'success') {
            toast.success('Welcome to my twitter')

            // get the data from the result
            const { email, name, token } = result['data']

            // cache properties inside session storage
            // if the keys do not exist, then they will get created with the current values
            // if exist then the values will get overwritten
            sessionStorage['username'] = name
            sessionStorage['email'] = email
            sessionStorage['token'] = token

            // go to home component
            navigate('/home')
          } else {
            toast.error('Invalid email or password')
          }
        })
    }
  }

  return (
    <div>
      <h1 className="page-title">Signin</h1>

      <div className="form-group">
        <div className="mb-3">
          <label>Email Address</label>
          <input
            onChange={(e) => {
              setEmail(e.target.value)
            }}
            type="text"
            className="form-control"
            placeholder="example@test.com"
          />
        </div>

        <div className="mb-3">
          <label>Password</label>
          <input
            onChange={(e) => {
              setPassword(e.target.value)
            }}
            type="password"
            className="form-control"
            placeholder="*******"
          />
        </div>

        <div className="mb-3">
          <p>
            Dont have an account? Signup <Link to="/signup">here</Link>.
          </p>
          <button onClick={onSignin} className="btn btn-success">
            Signin
          </button>
        </div>
      </div>
    </div>
  )
}

export default Signin
