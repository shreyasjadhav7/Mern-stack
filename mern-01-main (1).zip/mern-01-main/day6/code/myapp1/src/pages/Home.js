import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { toast } from 'react-toastify'
import Tweets from '../components/Tweets'

const Home = () => {
  const url = 'http://localhost:4000/tweet'

  // set the user name in state
  const [username, setUserName] = useState('')
  const [email, setEmail] = useState('')

  // use the tweets to store in to the state
  const [tweets, setTweets] = useState([])

  // used to navigation
  const navigate = useNavigate()

  // write the code which you want to execute
  // when the page gets loaded
  // this hook gets called only once
  useEffect(() => {
    setUserName(sessionStorage['username'])
    setEmail(sessionStorage['email'])

    getTweets()
  }, [])

  const onLogout = () => {
    // remove the user's information from session session
    sessionStorage.removeItem('username')
    sessionStorage.removeItem('email')
    sessionStorage.removeItem('token')

    // go to the signin component
    navigate('/signin')
  }

  const getTweets = () => {
    // read the token created at the time of signin
    const token = sessionStorage['token']

    // call the API to get the tweets
    axios
      .get(url, {
        // add the token in the headers
        headers: {
          token: token,
        },
      })
      .then((response) => {
        // read the json data sent by server
        const result = response.data

        if (result['status'] === 'success') {
          setTweets(result['data'])
        } else {
          toast.error(result['error'])
        }
      })
  }

  return (
    <div>
      <button
        style={{
          position: 'fixed',
          right: '10px',
        }}
        className="btn btn-link"
        onClick={onLogout}
      >
        Logout
      </button>
      <h1 className="page-title">Home</h1>
      <p style={{ textAlign: 'center' }}>
        Welcome back {username} ({email})
      </p>

      <div>
        <Tweets tweets={tweets} />
      </div>
    </div>
  )
}

export default Home
