import { useEffect, useState } from 'react'
import UserTableRow from '../components/UserTableRow'

const Page1 = () => {
  const url = 'https://reqres.in/api/users'

  // in the beginning the users will be undefined
  const [users, setUsers] = useState()

  // do something when the component is loaded successfully
  useEffect(() => {
    console.log('component got loaded')
    getUsers()
  }, [])

  // get the data from the URL
  const getUsers = () => {
    // make API call and get the data
    fetch(url)
      // once the (string) result is available
      // convert it into json object and return the result
      .then((result) => result.json())

      // once the json result is available
      // set it to the state and render the UI
      .then((result) => {
        setUsers(result)
      })
  }

  return (
    <div>
      <h1 className="page-title">Users List</h1>

      <table className="table table-stripped">
        <thead>
          <tr>
            <th>Avatar</th>
            <th>Id</th>
            <th>Email</th>
            <th>First Name</th>
            <th>Last Name</th>
          </tr>
        </thead>
        <tbody>
          {/* 
            conditional rendering
            - evaluate the condition 
            - if condition evaluation result is true only then 
              render the UI
          */}
          {users &&
            users.data.map((user) => {
              return <UserTableRow user={user} />
            })}
        </tbody>
      </table>
    </div>
  )
}

export default Page1
