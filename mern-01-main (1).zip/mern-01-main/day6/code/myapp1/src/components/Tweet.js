const Tweet = (props) => {
  const { date, message, title, user } = props.tweet

  return (
    <div style={{ marginBottom: '20px' }}>
      <div>
        <span style={{ fontWeight: 'bold' }}>{user.name}</span> posted on {date}
      </div>
      <div>{title}</div>
      <div>{message}</div>
    </div>
  )
}

export default Tweet
