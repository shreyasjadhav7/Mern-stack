import Tweet from './Tweet'

const Tweets = (props) => {
  const { tweets } = props
  return (
    <div>
      {tweets.map((tweet) => {
        return <Tweet key={tweet._id} tweet={tweet} />
      })}
    </div>
  )
}

export default Tweets
