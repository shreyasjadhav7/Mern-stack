const UserTableRow = (props) => {
  const { id, email, first_name, last_name, avatar } = props.user

  return (
    <tr>
      <td>
        <img style={{ width: '30px', height: '30px' }} src={avatar} />
      </td>
      <td>{id}</td>
      <td>{email}</td>
      <td>{first_name}</td>
      <td>{last_name}</td>
    </tr>
  )
}

export default UserTableRow
